SUSE L3 PTF for huawei.com/A087884

Bugs addressed: bsc#1198667, bsc#1203030
Case: 00358564

For more help look at:

https://www.suse.com/support/kb/doc/?id=000018572
https://www.suse.com/support/kb/doc/?id=000018545